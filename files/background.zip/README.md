# Better Yedion
## Description
This project was meant to enhance the experience with college websites based on Yedion.  
Currently, the extension enhances only the grade page.

## Installation
* Install from the Google Chrome Store:  
    ***Will be updated once approved***

* Install locally:
    1. Clone the project 
    2. Open chrome's extension manager (URL - `chrome://extensions`)
    3. toggle on the developer mode (top right) 
    4. Load the extension by clicking on the "Load unpacked" and select the cloned folder.